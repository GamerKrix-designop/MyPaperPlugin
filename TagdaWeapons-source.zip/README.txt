TagdaWeapons - Tagda SMP custom weapons (Paper 1.21.4+)

BUILD:
  1. Java 21 + Maven install karo (ya IntelliJ me folder open karo)
  2. Folder me: mvn clean package
  3. target/TagdaWeapons.jar ko server ke plugins/ folder me daalo

TEXTURES:
  TagdaSMP-ResourcePack.zip ko kisi direct-download link pe upload karo,
  phir plugins/TagdaWeapons/config.yml me url + sha1 daalo, /cw reload.

COMMANDS:
  /cw list
  /cw give <dragon_blade|elite_blade|lightning_sword|doom_hammer|crimson_bow|all> [player]
  /cw reload
