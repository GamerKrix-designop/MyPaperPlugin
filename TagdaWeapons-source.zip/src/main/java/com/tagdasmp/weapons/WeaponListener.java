package com.tagdasmp.weapons;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.Listener;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class WeaponListener implements Listener {

    private final TagdaWeapons plugin;
    private final WeaponItems items;
    private final List<NamespacedKey> recipeKeys;
    private final NamespacedKey arrowKey;

    private final Map<UUID, Map<Weapon, Long>> cooldowns = new HashMap<>();

    public WeaponListener(TagdaWeapons plugin, WeaponItems items, List<NamespacedKey> recipeKeys) {
        this.plugin = plugin;
        this.items = items;
        this.recipeKeys = recipeKeys;
        this.arrowKey = new NamespacedKey(plugin, "crimson_arrow");
    }

    // ---------------------------------------------------------------- join
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        p.discoverRecipes(recipeKeys);

        String url = plugin.getConfig().getString("resource-pack.url", "");
        String sha1 = plugin.getConfig().getString("resource-pack.sha1", "");
        if (url != null && !url.isBlank()) {
            if (sha1 != null && !sha1.isBlank()) {
                p.setResourcePack(url, sha1);
            } else {
                p.setResourcePack(url);
            }
        }
    }

    // ------------------------------------------------- right click abilities
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Weapon weapon = items.identify(e.getItem());
        if (weapon == null || weapon == Weapon.CRIMSON_BOW) return; // bow alag handle hota hai

        Player p = e.getPlayer();
        if (!p.hasPermission("tagdaweapons.use")) return;

        if (onCooldown(p, weapon)) return;

        boolean used = switch (weapon) {
            case DRAGON_BLADE -> dragonBreath(p);
            case ELITE_BLADE -> eliteDash(p);
            case LIGHTNING_SWORD -> thunderStrike(p);
            case DOOM_HAMMER -> doomSlam(p);
            default -> false;
        };

        if (used) {
            setCooldown(p, weapon);
        }
    }

    // 1. Dragon Blade - aag ka cone
    private boolean dragonBreath(Player p) {
        World world = p.getWorld();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        double range = 8.0;

        for (double d = 1; d <= range; d += 0.5) {
            Location l = eye.clone().add(dir.clone().multiply(d));
            world.spawnParticle(Particle.FLAME, l, 6, 0.3, 0.3, 0.3, 0.02);
            world.spawnParticle(Particle.SOUL_FIRE_FLAME, l, 2, 0.2, 0.2, 0.2, 0.01);
            world.spawnParticle(Particle.SMOKE, l, 2, 0.2, 0.2, 0.2, 0.01);
        }
        world.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 1.2f);
        world.playSound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);

        for (Entity en : p.getNearbyEntities(range, range, range)) {
            if (!(en instanceof LivingEntity le)) continue;
            Vector to = le.getEyeLocation().toVector().subtract(eye.toVector());
            if (to.length() > range) continue;
            if (dir.angle(to) > Math.toRadians(30)) continue;
            le.damage(7.0, p);
            le.setFireTicks(100);
        }
        return true;
    }

    // 2. Elite Blade - dash + buffs
    private boolean eliteDash(Player p) {
        World world = p.getWorld();
        Vector dir = p.getLocation().getDirection().setY(0).normalize().multiply(1.8).setY(0.2);
        p.setVelocity(dir);
        p.setFallDistance(0);

        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20 * 8, 1));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 8, 1));

        world.playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.8f);
        world.playSound(p.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1f, 1f);

        // dash ke baad aas-paas ke enemies ko damage
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!p.isOnline() || ticks++ > 8) {
                    cancel();
                    return;
                }
                Location loc = p.getLocation().add(0, 1, 0);
                world.spawnParticle(Particle.CLOUD, loc, 6, 0.3, 0.3, 0.3, 0.02);
                world.spawnParticle(Particle.CRIT, loc, 8, 0.4, 0.4, 0.4, 0.2);
                if (ticks == 5) {
                    for (Entity en : p.getNearbyEntities(3, 2, 3)) {
                        if (en instanceof LivingEntity le) {
                            le.damage(6.0, p);
                            le.setVelocity(le.getLocation().toVector().subtract(p.getLocation().toVector())
                                    .normalize().multiply(0.8).setY(0.4));
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
        return true;
    }

    // 3. Lightning Sword - target pe bijli
    private boolean thunderStrike(Player p) {
        World world = p.getWorld();
        Location eye = p.getEyeLocation();

        RayTraceResult result = world.rayTrace(eye, eye.getDirection(), 30, FluidCollisionMode.NEVER, true, 0.6,
                en -> en != p && en instanceof LivingEntity);

        if (result == null) {
            p.sendActionBar(Component.text("Koi target nahi mila!", NamedTextColor.RED));
            return false;
        }

        Location target;
        LivingEntity hit = null;
        if (result.getHitEntity() instanceof LivingEntity le) {
            hit = le;
            target = le.getLocation();
        } else {
            target = result.getHitPosition().toLocation(world);
        }

        if (target.distance(p.getLocation()) < 4) {
            p.sendActionBar(Component.text("Target bahut paas hai!", NamedTextColor.RED));
            return false;
        }

        world.strikeLightning(target);
        world.spawnParticle(Particle.ELECTRIC_SPARK, target, 40, 1, 1, 1, 0.3);
        if (hit != null) {
            hit.damage(5.0, p);
        }
        return true;
    }

    // 4. Doom Hammer - ground slam
    private boolean doomSlam(Player p) {
        World world = p.getWorld();
        Location loc = p.getLocation();
        double radius = 6.0;

        world.spawnParticle(Particle.EXPLOSION_EMITTER, loc, 1);
        for (int i = 0; i < 360; i += 15) {
            double rad = Math.toRadians(i);
            for (double r = 1; r <= radius; r += 1.5) {
                Location l = loc.clone().add(Math.cos(rad) * r, 0.2, Math.sin(rad) * r);
                world.spawnParticle(Particle.CLOUD, l, 1, 0, 0, 0, 0.05);
                world.spawnParticle(Particle.FLAME, l, 1, 0.1, 0.1, 0.1, 0.02);
            }
        }
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.7f);
        world.playSound(loc, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.6f, 1.2f);

        for (Entity en : p.getNearbyEntities(radius, radius, radius)) {
            if (!(en instanceof LivingEntity le)) continue;
            Vector away = le.getLocation().toVector().subtract(loc.toVector());
            away.setY(0);
            if (away.lengthSquared() < 0.01) away = new Vector(0, 0, 1);
            away.normalize().multiply(1.1).setY(0.9);
            le.setVelocity(away);
            le.damage(9.0, p);
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20 * 3, 1));
        }
        return true;
    }

    // ---------------------------------------------------------- crimson bow
    @EventHandler
    public void onShoot(EntityShootBowEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (items.identify(e.getBow()) != Weapon.CRIMSON_BOW) return;
        if (!(e.getProjectile() instanceof AbstractArrow arrow)) return;

        arrow.setCritical(true);
        arrow.getPersistentDataContainer().set(arrowKey, PersistentDataType.BYTE, (byte) 1);

        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.4f, 1.6f);

        // red trail
        new BukkitRunnable() {
            @Override
            public void run() {
                if (arrow.isDead() || !arrow.isValid() || arrow.isInBlock()) {
                    cancel();
                    return;
                }
                arrow.getWorld().spawnParticle(Particle.DUST, arrow.getLocation(), 4, 0.05, 0.05, 0.05, 0,
                        new Particle.DustOptions(Color.fromRGB(220, 20, 60), 1.4f));
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent e) {
        if (!(e.getEntity() instanceof AbstractArrow arrow)) return;
        if (!arrow.getPersistentDataContainer().has(arrowKey, PersistentDataType.BYTE)) return;
        if (!(e.getHitEntity() instanceof LivingEntity victim)) return;

        victim.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 20 * 5, 1));
        victim.getWorld().spawnParticle(Particle.DUST, victim.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0,
                new Particle.DustOptions(Color.fromRGB(139, 0, 0), 1.6f));

        // lifesteal: shooter ko 2 hearts heal
        if (arrow.getShooter() instanceof Player shooter && shooter != victim) {
            double max = shooter.getAttribute(Attribute.MAX_HEALTH).getValue();
            shooter.setHealth(Math.min(max, shooter.getHealth() + 4.0));
            shooter.getWorld().spawnParticle(Particle.HEART, shooter.getLocation().add(0, 2, 0), 3, 0.3, 0.2, 0.3, 0);
        }
    }

    // -------------------------------------------------------------- cooldown
    private boolean onCooldown(Player p, Weapon weapon) {
        Map<Weapon, Long> map = cooldowns.get(p.getUniqueId());
        if (map == null) return false;
        Long until = map.get(weapon);
        if (until == null) return false;

        long left = until - System.currentTimeMillis();
        if (left > 0) {
            p.sendActionBar(Component.text(weapon.abilityName() + " cooldown: " + (left / 1000 + 1) + "s",
                    NamedTextColor.RED));
            return true;
        }
        return false;
    }

    private void setCooldown(Player p, Weapon weapon) {
        cooldowns.computeIfAbsent(p.getUniqueId(), k -> new EnumMap<>(Weapon.class))
                .put(weapon, System.currentTimeMillis() + weapon.cooldownSeconds() * 1000L);
        p.sendActionBar(Component.text(weapon.abilityName() + "!", weapon.color()));
    }
}
