package com.tagdasmp.weapons;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;

public class WeaponItems {

    private final NamespacedKey weaponKey;

    public WeaponItems(Plugin plugin) {
        this.weaponKey = new NamespacedKey(plugin, "weapon");
    }

    public ItemStack create(Weapon weapon) {
        ItemStack item = new ItemStack(weapon.material());
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text(weapon.displayName(), weapon.color())
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(Component.text("Ability: " + weapon.abilityName(), NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text(weapon.abilityDesc(), NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        if (weapon.cooldownSeconds() > 0) {
            lore.add(Component.text("Cooldown: " + weapon.cooldownSeconds() + "s", NamedTextColor.DARK_GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        lore.add(Component.empty());
        lore.add(Component.text(weapon == Weapon.CRIMSON_BOW ? "Right Click (Draw) = Ability" : "Right Click = Ability",
                        NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Tagda SMP Legendary", weapon.color())
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        meta.setUnbreakable(true);

        // Texture: resource pack me tagdasmp:<weapon_id> model
        meta.setItemModel(NamespacedKey.fromString("tagdasmp:" + weapon.id()));

        meta.getPersistentDataContainer().set(weaponKey, PersistentDataType.STRING, weapon.id());
        item.setItemMeta(meta);
        return item;
    }

    public Weapon identify(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String id = item.getItemMeta().getPersistentDataContainer().get(weaponKey, PersistentDataType.STRING);
        return id == null ? null : Weapon.fromId(id);
    }
}
