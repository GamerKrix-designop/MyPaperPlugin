package com.tagdasmp.weapons;

import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Material;

public enum Weapon {

    DRAGON_BLADE("dragon_blade", "Dragon Blade", Material.NETHERITE_SWORD, NamedTextColor.DARK_PURPLE,
            "Dragon Breath", "Aage ki taraf aag ka breath chhodta hai", 15),

    ELITE_BLADE("elite_blade", "Elite Blade", Material.DIAMOND_SWORD, NamedTextColor.AQUA,
            "Elite Dash", "Tez dash + Strength & Speed", 20),

    LIGHTNING_SWORD("lightning_sword", "Lightning Sword", Material.IRON_SWORD, NamedTextColor.YELLOW,
            "Thunder Strike", "Target pe bijli girata hai", 20),

    DOOM_HAMMER("doom_hammer", "Doom Hammer", Material.MACE, NamedTextColor.RED,
            "Doom Slam", "Zameen pe slam, aas-paas sab udd jaate hain", 25),

    CRIMSON_BOW("crimson_bow", "Crimson Bow", Material.BOW, TextColor.color(0xDC143C),
            "Blood Arrows", "Arrows Wither lagate hain + tumhe heal karte hain", 0);

    private final String id;
    private final String displayName;
    private final Material material;
    private final TextColor color;
    private final String abilityName;
    private final String abilityDesc;
    private final int cooldownSeconds;

    Weapon(String id, String displayName, Material material, TextColor color,
           String abilityName, String abilityDesc, int cooldownSeconds) {
        this.id = id;
        this.displayName = displayName;
        this.material = material;
        this.color = color;
        this.abilityName = abilityName;
        this.abilityDesc = abilityDesc;
        this.cooldownSeconds = cooldownSeconds;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material material() { return material; }
    public TextColor color() { return color; }
    public String abilityName() { return abilityName; }
    public String abilityDesc() { return abilityDesc; }
    public int cooldownSeconds() { return cooldownSeconds; }

    public static Weapon fromId(String id) {
        for (Weapon w : values()) {
            if (w.id.equalsIgnoreCase(id)) return w;
        }
        return null;
    }
}
