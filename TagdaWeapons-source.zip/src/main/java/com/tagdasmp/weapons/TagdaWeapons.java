package com.tagdasmp.weapons;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class TagdaWeapons extends JavaPlugin {

    private WeaponItems items;
    private final List<NamespacedKey> recipeKeys = new ArrayList<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        items = new WeaponItems(this);

        registerRecipes();

        getServer().getPluginManager().registerEvents(new WeaponListener(this, items, recipeKeys), this);

        WeaponCommand cmd = new WeaponCommand(this, items);
        getCommand("customweapon").setExecutor(cmd);
        getCommand("customweapon").setTabCompleter(cmd);

        getLogger().info("TagdaWeapons enabled - 5 custom weapons ready!");
    }

    private void registerRecipes() {
        // Dragon Blade:  Diamond Block / Netherite Ingot / Blaze Rod
        addRecipe(Weapon.DRAGON_BLADE, new String[]{" D ", " N ", " R "},
                'D', Material.DIAMOND_BLOCK, 'N', Material.NETHERITE_INGOT, 'R', Material.BLAZE_ROD);

        // Elite Blade:  Emerald, Diamond, Emerald / Diamond / Stick
        addRecipe(Weapon.ELITE_BLADE, new String[]{"EDE", " D ", " S "},
                'E', Material.EMERALD, 'D', Material.DIAMOND, 'S', Material.STICK);

        // Lightning Sword:  Lightning Rod / Iron + Diamond + Iron / Stick
        addRecipe(Weapon.LIGHTNING_SWORD, new String[]{" L ", "IDI", " S "},
                'L', Material.LIGHTNING_ROD, 'I', Material.IRON_INGOT, 'D', Material.DIAMOND, 'S', Material.STICK);

        // Doom Hammer:  Obsidian, Diamond Block, Obsidian / Blaze Rod / Blaze Rod
        addRecipe(Weapon.DOOM_HAMMER, new String[]{"OBO", " R ", " R "},
                'O', Material.OBSIDIAN, 'B', Material.DIAMOND_BLOCK, 'R', Material.BLAZE_ROD);

        // Crimson Bow:  Blaze Rod + String on both sides, Diamond in the middle
        addRecipe(Weapon.CRIMSON_BOW, new String[]{" RS", "RDS", " RS"},
                'R', Material.BLAZE_ROD, 'D', Material.DIAMOND, 'S', Material.STRING);
    }

    private void addRecipe(Weapon weapon, String[] shape, Object... ingredients) {
        NamespacedKey key = new NamespacedKey(this, "recipe_" + weapon.id());
        ShapedRecipe recipe = new ShapedRecipe(key, items.create(weapon));
        recipe.shape(shape);
        for (int i = 0; i < ingredients.length; i += 2) {
            recipe.setIngredient((Character) ingredients[i], (Material) ingredients[i + 1]);
        }
        getServer().addRecipe(recipe);
        recipeKeys.add(key);
    }
}
