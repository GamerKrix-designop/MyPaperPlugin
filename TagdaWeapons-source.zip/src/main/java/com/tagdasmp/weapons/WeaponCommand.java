package com.tagdasmp.weapons;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class WeaponCommand implements CommandExecutor, TabCompleter {

    private final TagdaWeapons plugin;
    private final WeaponItems items;

    public WeaponCommand(TagdaWeapons plugin, WeaponItems items) {
        this.plugin = plugin;
        this.items = items;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender, label);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "list" -> {
                sender.sendMessage(Component.text("=== Tagda SMP Weapons ===", NamedTextColor.GOLD));
                for (Weapon w : Weapon.values()) {
                    sender.sendMessage(Component.text(" - " + w.id(), w.color())
                            .append(Component.text("  (" + w.abilityName() + ")", NamedTextColor.GRAY)));
                }
                return true;
            }
            case "reload" -> {
                if (!sender.hasPermission("tagdaweapons.give")) {
                    sender.sendMessage(Component.text("Tumhe permission nahi hai.", NamedTextColor.RED));
                    return true;
                }
                plugin.reloadConfig();
                sender.sendMessage(Component.text("Config reload ho gaya!", NamedTextColor.GREEN));
                return true;
            }
            case "give" -> {
                if (!sender.hasPermission("tagdaweapons.give")) {
                    sender.sendMessage(Component.text("Tumhe permission nahi hai.", NamedTextColor.RED));
                    return true;
                }
                return handleGive(sender, args);
            }
            default -> {
                sendHelp(sender, label);
                return true;
            }
        }
    }

    private boolean handleGive(CommandSender sender, String[] args) {
        // /cw give <weapon|all> [player]
        if (args.length < 2) {
            sender.sendMessage(Component.text("Use: /cw give <weapon|all> [player]", NamedTextColor.RED));
            return true;
        }

        Player target;
        if (args.length >= 3) {
            target = Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                sender.sendMessage(Component.text("Player online nahi hai: " + args[2], NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(Component.text("Console se player ka naam dena zaroori hai.", NamedTextColor.RED));
            return true;
        }

        List<Weapon> toGive = new ArrayList<>();
        if (args[1].equalsIgnoreCase("all")) {
            toGive.addAll(List.of(Weapon.values()));
        } else {
            Weapon w = Weapon.fromId(args[1]);
            if (w == null) {
                sender.sendMessage(Component.text("Weapon nahi mila. /cw list use karo.", NamedTextColor.RED));
                return true;
            }
            toGive.add(w);
        }

        for (Weapon w : toGive) {
            ItemStack item = items.create(w);
            HashMap<Integer, ItemStack> leftover = target.getInventory().addItem(item);
            // Inventory full ho toh zameen pe drop
            leftover.values().forEach(i -> target.getWorld().dropItemNaturally(target.getLocation(), i));
        }

        sender.sendMessage(Component.text("Diya: " + (toGive.size() == 1 ? toGive.get(0).displayName() : "sab 5 weapons")
                + " -> " + target.getName(), NamedTextColor.GREEN));
        if (sender != target) {
            target.sendMessage(Component.text("Tumhe custom weapon mila!", NamedTextColor.GOLD));
        }
        return true;
    }

    private void sendHelp(CommandSender sender, String label) {
        sender.sendMessage(Component.text("=== TagdaWeapons ===", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("/" + label + " list", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("/" + label + " give <weapon|all> [player]", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("/" + label + " reload", NamedTextColor.YELLOW));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("list");
            if (sender.hasPermission("tagdaweapons.give")) {
                out.add("give");
                out.add("reload");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Weapon w : Weapon.values()) out.add(w.id());
            out.add("all");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
